Programa que lee un archivo binario, sus datos los almacena y ordena ascendentemente con tres algoritmos de distinta complejidad, transforma los datos en un formato .pbm para entregar tres imágenes hechas con los distintos algoritmos, Finalmente entrega un reporte que demuestra las distintas complejedidas mostrando cuantos procesos hicieron y cuanto se demoró cada algoritmo.
El archivo se entrega como parámetro del ejecutable.

Las condiciones de compilación y ejecución es tener un compilador de lenguaje C en un entorno Linux.

Para compilar, escribir en consola el comando make o en su defecto, compilar con "gcc -o tarea2 code.c sort.c". 
Para ejecutar, escribir en consola "./tarea2 Nombre_archivo", donde "Nombre_archivo" es el archivo binario a trabajar, en entorno Linux. 

José Luis Beltrán Mobarec, 202030548-K.
